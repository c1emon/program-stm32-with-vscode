Readme.txt for BSP for AT91SAM7S256

Supported hardware:
===================
The sample project for ATMEL AT91SAM7S256 is prepared
to run on an ATMEL AT91SAM7S256-EK eval board,
but may be used on other target hardware as well.

Configurations
==============
- RAM:
  This configuration is prepared for download into 
  internal RAM using J-Link and GDB. A call of 
  AT91SAM7_RAM_JLink.gdb ensures that internal RAM
  is mapped at 0x00.

- FLASH:
  This configuration is prepared for debugging and
  can be downloaded into internal FLASH using the
  J-Link GDB Server.
  A call of AT91SAM7_FLASH_JLink.gdb ensures that 
  FLASH is mapped at 0x00.
