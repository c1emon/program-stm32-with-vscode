/*********************************************************************
*              SEGGER MICROCONTROLLER GmbH & Co. KG                  *
*        Solutions for real time microcontroller applications        *
**********************************************************************
*                                                                    *
*        (c) 2011 SEGGER Microcontroller GmbH & Co. KG               *
*                                                                    *
* Internet: www.segger.com Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : Readme.txt
Purpose : Basic information about this sample project
---------------------------END-OF-HEADER------------------------------

For using this project with IAR EWARM V6.30.1-3142
a patch is needed to make the XMC4500 selectable in EWARM.

The script files
XMC4500_Generic_Debug_FLASH.JLinkScript
XMC4500_Generic_Debug_RAM.JLinkScript

in the settings directory are necessary to guarantee a stable connection to the target.
When creating a custom project, these script files should be 

For more information about how to use J-Link script files in custom projects, please refer to UM08001
