This package includes the following projects:


  - LPC4350_CortexM0_IARV630 (Sample project to debug the Cortex-M0 core on the LPC4350)
  - LPC4350_CortexM4_IARV630 (Sample project to debug the Cortex-M4 core on the LPC4350)

*************************************************************************************************************

Simple sample projects to demonstrate dual core debugging on a LPC4350.
These projects are hardware independent but have been tested on the Hitex LPC1850EVA-02 evaluation board

Usage:
  - Start debug session with LPC4350_CortexM4_IARV630 project
  - Open second instance of IAR EWARM and open LPC4350_CortexM0_IARV630
  - Start second debug session and let the Cortex-M0 run

The Cortex-M4 simply sends a defined command to the Cortex-M0 using shared memory
and waits for the response before it resumes execution.
The Cortex-M0 waits for command reception from the Cortex-M4 and simply sends back a "received-response"
using shared memory.

*************************************************************************************************************

Requirements to use these projects:
  - J-Link
  - J-Link software version V4.37a or later
  - IAR EWARM V6.30

Note: The J-Link script files located in the settings directories are necessary to make the projects work correctly.
