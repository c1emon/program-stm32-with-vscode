#define U32 unsigned long

#define CMD_M4       (*((volatile U32 *)(0x10010000)))
#define RESPONSE_M0  (*((volatile U32 *)(0x10010004)))
