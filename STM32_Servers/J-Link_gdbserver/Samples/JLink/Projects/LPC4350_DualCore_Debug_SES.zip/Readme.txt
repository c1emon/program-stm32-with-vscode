This package includes the following projects:

  - LPC4350_CortexM0_SES (Sample project to debug the Cortex-M0 core on the LPC4350)
  - LPC4350_CortexM4_SES (Sample project to debug the Cortex-M4 core on the LPC4350)

*************************************************************************************************************

Simple sample projects to demonstrate dual core debugging on a LPC4350.
These projects are hardware independent but have been tested on the Arrow LPC-4350-DB1 Rev.B evaluation board

Usage:
  - Start debug session with LPC4350_CortexM4_SES project
  - Open second instance of Embedded Studio and open LPC4350_CortexM0_SES
  - Start second debug session and let the Cortex-M0 run

The Cortex-M4 simply sends a defined command to the Cortex-M0 using shared memory and waits for the response
before it resumes execution. The Cortex-M0 waits for command reception from the Cortex-M4 and simply sends
back a "received-response" using shared memory.

*************************************************************************************************************

Requirements to use these projects:
  - J-Link
  - J-Link software version V6.00g or later
  - SEGGER Embedded Studio V3.10
