/*********************************************************************
*              SEGGER MICROCONTROLLER GmbH & Co. KG                  *
*        Solutions for real time microcontroller applications        *
**********************************************************************
*                                                                    *
*        (c) 2010 SEGGER Microcontroller GmbH & Co. KG               *
*                                                                    *
* Internet: www.segger.com Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : Main.c
Purpose : Main function of generic Kinetis ETB Trace sample project
---------------------------END-OF-HEADER------------------------------
*/
volatile int Cnt;

#ifdef DEBUG_FLASH
//
// From 0x400 - 0x40F there is a configuration area in flash memory.
// It can be erased & programmed as the rest of the flash memory,
// but there are several bytes which are used for target configuration
// For example, the byte at 0x40C controls the security mode of the device.
// If this byte is 0xFF, the device is secured, so we set it to 0xFE which means non-secured.
//
#pragma section="FlashConfig"
#pragma location = "FlashConfig"
__root const unsigned int aConfigArea[4] @ "FlashConfig" = {
  0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFE
};
#endif

/*********************************************************************
*
*       main
*/
void main(void) {
  while(1) {
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
    Cnt++;
  }
}
